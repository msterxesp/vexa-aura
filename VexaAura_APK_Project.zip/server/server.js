import express from 'express';
import cors from 'cors';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET||'CHANGE_THIS_VEXA_SECRET';
const db=new Database(path.join(__dirname,'vexa.sqlite'));
db.pragma('journal_mode=WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT,ff_uid TEXT,phone TEXT,win_coins INTEGER DEFAULT 0,deposit_coins INTEGER DEFAULT 0,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS tournaments(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,mode TEXT NOT NULL,map TEXT NOT NULL,slots INTEGER NOT NULL,prize TEXT NOT NULL,fee INTEGER DEFAULT 0,time INTEGER NOT NULL,room_id TEXT,room_pass TEXT,created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS joins(id INTEGER PRIMARY KEY AUTOINCREMENT,tournament_id INTEGER NOT NULL,user_id INTEGER NOT NULL,joined_at INTEGER NOT NULL,UNIQUE(tournament_id,user_id));
CREATE TABLE IF NOT EXISTS deposits(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,amount INTEGER NOT NULL,screenshot TEXT NOT NULL,status TEXT DEFAULT 'pending',created_at INTEGER NOT NULL,reviewed_at INTEGER,reviewed_by INTEGER);
CREATE TABLE IF NOT EXISTS withdrawals(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,method TEXT NOT NULL,detail TEXT NOT NULL,amount INTEGER NOT NULL,status TEXT DEFAULT 'pending',created_at INTEGER NOT NULL,reviewed_at INTEGER,reviewed_by INTEGER);
CREATE TABLE IF NOT EXISTS results(id INTEGER PRIMARY KEY AUTOINCREMENT,tournament_id INTEGER NOT NULL,user_id INTEGER NOT NULL,place INTEGER NOT NULL,kills INTEGER NOT NULL,points INTEGER NOT NULL,UNIQUE(tournament_id,user_id));
`);
const now=()=>Date.now();
const hash=p=>bcrypt.hashSync(p,12);
const existing=db.prepare('SELECT id FROM admins WHERE username=?').get('MASTERNVRDIE');
if(!existing) db.prepare('INSERT INTO admins(username,password_hash,role,created_at) VALUES(?,?,?,?)').run('MASTERNVRDIE',hash('MASTER@90'),'owner',now());

app.use(cors()); app.use(express.json({limit:'2mb'}));
const uploadDir=path.join(__dirname,'public/uploads'); fs.mkdirSync(uploadDir,{recursive:true});
const storage=multer.diskStorage({destination:uploadDir,filename:(req,file,cb)=>cb(null,`${Date.now()}-${Math.random().toString(36).slice(2)}${path.extname(file.originalname).toLowerCase()}`)});
const upload=multer({storage,limits:{fileSize:5*1024*1024},fileFilter:(req,file,cb)=>cb(null,/^image\/(png|jpe?g|webp)$/.test(file.mimetype))});

function token(user){return jwt.sign({id:user.id,username:user.username,role:user.role||'user'},JWT_SECRET,{expiresIn:'7d'})}
function auth(req,res,next){try{const h=req.headers.authorization||'';if(!h.startsWith('Bearer ')) throw 0;req.auth=jwt.verify(h.slice(7),JWT_SECRET);next()}catch{res.status(401).json({error:'Login required'})}}
function staff(req,res,next){if(req.auth?.role!=='owner'&&req.auth?.role!=='staff') return res.status(403).json({error:'Staff/Admin only'});next()}
function owner(req,res,next){if(req.auth?.role!=='owner') return res.status(403).json({error:'Admin only'});next()}
function points(place,kills){return Math.max(0,100-place*10)+kills*2}

app.get('/api/health',(req,res)=>res.json({ok:true}));
app.get('/api/qr',(req,res)=>res.sendFile(path.join(__dirname,'public/vexa-aura-qr.jpg')));
app.post('/api/register',(req,res)=>{const {username,ffUid,phone}=req.body||{};if(!username||username.length<2) return res.status(400).json({error:'Username required'});let u=db.prepare('SELECT * FROM users WHERE username=?').get(username);if(!u){const info=db.prepare('INSERT INTO users(username,ff_uid,phone,created_at) VALUES(?,?,?,?)').run(username,ffUid||'',phone||'',now());u=db.prepare('SELECT * FROM users WHERE id=?').get(info.lastInsertRowid)} else db.prepare('UPDATE users SET ff_uid=?,phone=? WHERE id=?').run(ffUid||u.ff_uid,phone||u.phone,u.id);res.json({token:token(u),user:{id:u.id,username:u.username,ffUid:u.ff_uid,phone:u.phone,winCoins:u.win_coins,depositCoins:u.deposit_coins}})});
app.get('/api/me',auth,(req,res)=>{const u=db.prepare('SELECT * FROM users WHERE id=?').get(req.auth.id);if(!u)return res.status(404).json({error:'User not found'});res.json({user:{id:u.id,username:u.username,ffUid:u.ff_uid,phone:u.phone,winCoins:u.win_coins,depositCoins:u.deposit_coins}})});
app.get('/api/tournaments',auth,(req,res)=>{const rows=db.prepare(`SELECT t.*,COUNT(j.id) player_count,(SELECT COUNT(*) FROM joins j2 WHERE j2.tournament_id=t.id AND j2.user_id=?) joined FROM tournaments t LEFT JOIN joins j ON j.tournament_id=t.id GROUP BY t.id ORDER BY t.time ASC`).all(req.auth.id);res.json(rows.map(r=>({...r,playerCount:r.player_count,joined:!!r.joined})))});
app.get('/api/tournaments/:id',auth,(req,res)=>{const t=db.prepare('SELECT * FROM tournaments WHERE id=?').get(req.params.id);if(!t)return res.status(404).json({error:'Tournament not found'});const players=db.prepare(`SELECT u.id,u.username,u.ff_uid,j.joined_at,r.place,r.kills,r.points FROM joins j JOIN users u ON u.id=j.user_id LEFT JOIN results r ON r.tournament_id=j.tournament_id AND r.user_id=j.user_id WHERE j.tournament_id=? ORDER BY COALESCE(r.place,999),u.username`).all(t.id);res.json({...t,playerCount:players.length,joined:!!db.prepare('SELECT 1 FROM joins WHERE tournament_id=? AND user_id=?').get(t.id,req.auth.id),players})});
app.post('/api/tournaments/:id/join',auth,(req,res)=>{const t=db.prepare('SELECT * FROM tournaments WHERE id=?').get(req.params.id);if(!t)return res.status(404).json({error:'Tournament not found'});const c=db.prepare('SELECT COUNT(*) c FROM joins WHERE tournament_id=?').get(t.id).c;if(c>=t.slots)return res.status(400).json({error:'Slots full'});if(db.prepare('SELECT 1 FROM joins WHERE tournament_id=? AND user_id=?').get(t.id,req.auth.id))return res.status(400).json({error:'Already joined'});const u=db.prepare('SELECT * FROM users WHERE id=?').get(req.auth.id);const fee=Number(req.body?.fee||0);if(fee>0){let dep=u.deposit_coins,win=u.win_coins;if(dep+win<fee)return res.status(400).json({error:'Insufficient coins'});const takeDep=Math.min(dep,fee),takeWin=fee-takeDep;db.prepare('UPDATE users SET deposit_coins=deposit_coins-?,win_coins=win_coins-? WHERE id=?').run(takeDep,takeWin,u.id)}db.prepare('INSERT INTO joins(tournament_id,user_id,joined_at) VALUES(?,?,?)').run(t.id,u.id,now());res.json({ok:true})});
app.post('/api/deposits',auth,upload.single('screenshot'),(req,res)=>{const amount=Number(req.body?.amount);if(!req.file||!Number.isInteger(amount)||amount<=0)return res.status(400).json({error:'Amount and screenshot required'});db.prepare('INSERT INTO deposits(user_id,amount,screenshot,created_at) VALUES(?,?,?,?)').run(req.auth.id,amount,`/uploads/${req.file.filename}`,now());res.json({ok:true,message:'Your deposit request will approve/reject in 2 hours'})});
app.post('/api/withdrawals',auth,(req,res)=>{const {method,detail}=req.body||{},amount=Number(req.body?.amount);if(!['upi','redeem'].includes(method)||!detail||!Number.isInteger(amount)||amount<=0)return res.status(400).json({error:'Invalid withdrawal request'});const u=db.prepare('SELECT win_coins FROM users WHERE id=?').get(req.auth.id);if(u.win_coins<amount)return res.status(400).json({error:'Insufficient Win Coins'});db.prepare('INSERT INTO withdrawals(user_id,method,detail,amount,created_at) VALUES(?,?,?,?,?)').run(req.auth.id,method,detail,amount,now());res.json({ok:true})});

app.post('/api/admin/login',(req,res)=>{const {username,password}=req.body||{};const a=db.prepare('SELECT * FROM admins WHERE username=?').get(username);if(!a||!bcrypt.compareSync(password||'',a.password_hash))return res.status(401).json({error:'Wrong login'});res.json({token:token(a),username:a.username,role:a.role})});
app.get('/api/admin/requests',auth,staff,(req,res)=>{const deposits=db.prepare(`SELECT d.*,u.username,u.ff_uid FROM deposits d JOIN users u ON u.id=d.user_id ORDER BY d.created_at DESC`).all();const withdrawals=db.prepare(`SELECT w.*,u.username,u.ff_uid FROM withdrawals w JOIN users u ON u.id=w.user_id ORDER BY w.created_at DESC`).all();res.json({deposits,withdrawals})});
app.post('/api/admin/deposits/:id/review',auth,owner,(req,res)=>{const d=db.prepare('SELECT * FROM deposits WHERE id=?').get(req.params.id);if(!d||d.status!=='pending')return res.status(400).json({error:'Already reviewed/not found'});const status=req.body?.status;if(!['approved','rejected'].includes(status))return res.status(400).json({error:'Invalid status'});const tx=db.transaction(()=>{db.prepare('UPDATE deposits SET status=?,reviewed_at=?,reviewed_by=? WHERE id=?').run(status,now(),req.auth.id,d.id);if(status==='approved')db.prepare('UPDATE users SET deposit_coins=deposit_coins+? WHERE id=?').run(d.amount,d.user_id)});tx();res.json({ok:true})});
app.post('/api/admin/withdrawals/:id/review',auth,owner,(req,res)=>{const w=db.prepare('SELECT * FROM withdrawals WHERE id=?').get(req.params.id);if(!w||w.status!=='pending')return res.status(400).json({error:'Already reviewed/not found'});const status=req.body?.status;if(!['approved','rejected'].includes(status))return res.status(400).json({error:'Invalid status'});const tx=db.transaction(()=>{if(status==='approved'){const u=db.prepare('SELECT win_coins FROM users WHERE id=?').get(w.user_id);if(u.win_coins<w.amount)throw new Error('User no longer has enough Win Coins');db.prepare('UPDATE users SET win_coins=win_coins-? WHERE id=?').run(w.amount,w.user_id)}db.prepare('UPDATE withdrawals SET status=?,reviewed_at=?,reviewed_by=? WHERE id=?').run(status,now(),req.auth.id,w.id)});try{tx();res.json({ok:true})}catch(e){res.status(400).json({error:e.message})}});
app.post('/api/admin/tournaments',auth,staff,(req,res)=>{const {title,mode,map,slots,prize,time,fee}=req.body||{};if(!title||!mode||!map||!slots||!prize||!time)return res.status(400).json({error:'Missing fields'});const info=db.prepare('INSERT INTO tournaments(title,mode,map,slots,prize,fee,time,created_at) VALUES(?,?,?,?,?,?,?,?)').run(title,mode,map,Number(slots),prize,Number(fee||0),Number(time),now());res.json({id:info.lastInsertRowid})});
app.patch('/api/admin/tournaments/:id/room',auth,staff,(req,res)=>{db.prepare('UPDATE tournaments SET room_id=?,room_pass=? WHERE id=?').run(req.body?.room||'',req.body?.pass||'',req.params.id);res.json({ok:true})});
app.delete('/api/admin/tournaments/:id',auth,staff,(req,res)=>{db.prepare('DELETE FROM tournaments WHERE id=?').run(req.params.id);res.json({ok:true})});
app.get('/api/admin/tournaments/:id/players',auth,staff,(req,res)=>res.json(db.prepare(`SELECT u.id,u.username,u.ff_uid FROM joins j JOIN users u ON u.id=j.user_id WHERE j.tournament_id=?`).all(req.params.id)));
app.post('/api/admin/tournaments/:id/results',auth,staff,(req,res)=>{const items=req.body?.results||[];const tx=db.transaction(()=>{for(const x of items){const p=Number(x.place),k=Number(x.kills);if(!x.userId||!p||k<0)continue;const pts=points(p,k);db.prepare('INSERT INTO results(tournament_id,user_id,place,kills,points) VALUES(?,?,?,?,?) ON CONFLICT(tournament_id,user_id) DO UPDATE SET place=excluded.place,kills=excluded.kills,points=excluded.points').run(req.params.id,x.userId,p,k,pts)}});tx();res.json({ok:true})});
app.get('/api/leaderboard',auth,(req,res)=>res.json(db.prepare(`SELECT u.username,COALESCE(SUM(r.points),0) points,COALESCE(SUM(r.kills),0) kills FROM users u LEFT JOIN results r ON r.user_id=u.id GROUP BY u.id ORDER BY points DESC,kills DESC LIMIT 100`).all()));
app.post('/api/admin/staff',auth,owner,(req,res)=>{const {username,password}=req.body||{};if(!username||!password)return res.status(400).json({error:'Missing fields'});try{db.prepare('INSERT INTO admins(username,password_hash,role,created_at) VALUES(?,?,?,?)').run(username,hash(password),'staff',now());res.json({ok:true})}catch{res.status(400).json({error:'Username already exists'})}});
app.get('/api/admin/staff',auth,owner,(req,res)=>res.json(db.prepare("SELECT id,username,role,created_at FROM admins WHERE role='staff' ORDER BY id DESC").all()));
app.delete('/api/admin/staff/:id',auth,owner,(req,res)=>{db.prepare("DELETE FROM admins WHERE id=? AND role='staff'").run(req.params.id);res.json({ok:true})});
app.post('/api/admin/password',auth,owner,(req,res)=>{if(!req.body?.password)return res.status(400).json({error:'Password required'});db.prepare('UPDATE admins SET password_hash=? WHERE id=?').run(hash(req.body.password),req.auth.id);res.json({ok:true})});

app.use('/uploads',express.static(uploadDir));
app.use(express.static(path.join(__dirname,'public')));
app.use((req,res)=>res.sendFile(path.join(__dirname,'public/index.html')));
app.listen(PORT,()=>console.log(`Vexa Aura server on :${PORT}`));
