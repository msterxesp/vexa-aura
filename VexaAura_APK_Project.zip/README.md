# Vexa Aura — APK-ready project

This is a fresh Vexa Aura tournament app project with:
- User home, matches, leaderboard, profile
- Wallet: Win Coins + Deposit Coins
- Deposit flow: amount -> QR -> screenshot -> request
- Withdraw: UPI or Redeem Code
- Admin requests with approve/reject
- Staff can view requests but cannot approve/reject
- Match creation and management
- Admin credentials initially: `MASTERNVRDIE` / `MASTER@90`
- QR asset included in `server/public/vexa-aura-qr.jpg`

## Important
The APK needs the server to be hosted on HTTPS. Set the server URL in `localStorage` key `vexa_api` before packaging, or change `API` in `web/app.js` to your HTTPS API URL.

## Free phone-only build
1. Upload this project to GitHub from your phone.
2. Deploy `/server` to a Node hosting service.
3. Put the HTTPS server URL into `web/app.js` as `const API='https://YOUR-SERVER';`.
4. Run the GitHub Actions workflow `Build Vexa Aura APK`.
5. Download the generated debug APK from the Actions artifact.

For a production release, use a proper signed Android App Bundle/APK and secure secrets.
